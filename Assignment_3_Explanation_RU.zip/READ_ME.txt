Assignment 3 NLP: 20-page Russian guide.
For each task: requirements, numbered code with explanations, saved outputs, theory and defense questions.
Open ASSIGNMENT_3_EXPLAINED_RU.pdf in any PDF reader. Python is not required.
